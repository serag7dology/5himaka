<?php

namespace FleetCart;

class FleetCart
{
    /**
     * The FleetCart version.
     *
     * @var string
     */
    const VERSION = '2.0.0';

    /**
     * The envato item ID.
     *
     * @var string
     */
    const ITEM_ID = '23014826';
}
