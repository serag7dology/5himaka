<?php

return [
    'admin.taxes' => [
        'index' => 'tax::permissions.taxes.index',
        'create' => 'tax::permissions.taxes.create',
        'edit' => 'tax::permissions.taxes.edit',
        'destroy' => 'tax::permissions.taxes.destroy',
    ],
];
