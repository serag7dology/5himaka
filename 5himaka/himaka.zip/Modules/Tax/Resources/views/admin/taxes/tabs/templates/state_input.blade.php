<script type="text/html" id="state-input-template">
    <input type="text" name="rates[<%- rateId %>][state]" class="form-control" id="rates.<%- rateId %>.state" placeholder="*">
</script>
