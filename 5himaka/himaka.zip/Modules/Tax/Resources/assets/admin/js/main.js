import TaxRates from './TaxRates';

window.admin.removeSubmitButtonOffsetOn('#rates');

new TaxRates();
