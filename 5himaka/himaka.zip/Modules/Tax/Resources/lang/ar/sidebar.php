<?php

return [
    'taxes' => 'Taxes',
];
