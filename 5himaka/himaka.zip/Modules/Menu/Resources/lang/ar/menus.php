<?php

return [
    'menu' => 'Menu',
    'menus' => 'Menus',
    'table' => [
        'name' => 'Name',
    ],
    'form' => [
        'please_save_the_menu_first' => 'Please save the menu first to add menu items.',
        'enable_the_menu' => 'Enable the menu',
    ],
];
