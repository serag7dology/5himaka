<?php

return [
    'admin.settings' => [
        'edit' => 'setting::permissions.edit',
    ],
];
