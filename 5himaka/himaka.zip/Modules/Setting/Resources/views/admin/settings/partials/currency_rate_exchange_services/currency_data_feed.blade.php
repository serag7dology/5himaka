{{ Form::password('currency_data_feed_api_key', trans('setting::attributes.currency_data_feed_api_key'), $errors, $settings, ['required' => true]) }}
