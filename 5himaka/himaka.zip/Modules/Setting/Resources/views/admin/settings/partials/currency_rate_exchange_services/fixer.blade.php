{{ Form::password('fixer_access_key', trans('setting::attributes.fixer_access_key'), $errors, $settings, ['required' => true]) }}
