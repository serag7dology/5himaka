{{ Form::password('forge_api_key', trans('setting::attributes.forge_api_key'), $errors, $settings, ['required' => true]) }}
