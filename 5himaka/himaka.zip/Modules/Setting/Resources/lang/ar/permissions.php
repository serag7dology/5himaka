<?php

return [
    'edit' => 'Edit Settings',
];
