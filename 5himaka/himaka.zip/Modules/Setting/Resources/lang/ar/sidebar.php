<?php

return [
    'settings' => 'Settings',
    'general' => 'General',
];
