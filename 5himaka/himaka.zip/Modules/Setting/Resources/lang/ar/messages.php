<?php

return [
    'settings_have_been_saved' => 'Settings have been saved.',
];
