<?php

return [
    'admin.pages' => [
        'index' => 'page::permissions.index',
        'create' => 'page::permissions.create',
        'edit' => 'page::permissions.edit',
        'destroy' => 'page::permissions.destroy',
    ],
];
