<?php

return [
    'index' => 'Index Pages',
    'create' => 'Create Pages',
    'edit' => 'Edit Pages',
    'destroy' => 'Delete Pages',
];
