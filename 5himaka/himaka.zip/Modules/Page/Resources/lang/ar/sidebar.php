<?php

return [
    'pages' => 'Pages',
];
