<?php

return [
    'name' => 'Name',
    'slug' => 'URL',
    'body' => 'Body',
    'is_active' => 'Status',
];
