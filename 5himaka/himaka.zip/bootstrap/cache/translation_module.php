<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Translation\\Providers\\TranslationServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Translation\\Providers\\TranslationServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);