<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Checkout\\Providers\\EventServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Checkout\\Providers\\EventServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);