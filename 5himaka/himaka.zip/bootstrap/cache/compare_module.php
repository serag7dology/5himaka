<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Compare\\Providers\\CompareServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Compare\\Providers\\CompareServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);