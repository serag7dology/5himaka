<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Review\\Providers\\ReviewServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Review\\Providers\\ReviewServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);