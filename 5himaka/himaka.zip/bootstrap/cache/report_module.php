<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Report\\Providers\\ReportServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Report\\Providers\\ReportServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);